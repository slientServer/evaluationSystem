-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : easycms
-- 
-- Part : #1
-- Date : 2016-01-30 21:57:20
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `easy_access`
-- -----------------------------
DROP TABLE IF EXISTS `easy_access`;
;


-- -----------------------------
-- Table structure for `easy_ads`
-- -----------------------------
DROP TABLE IF EXISTS `easy_ads`;
;

-- -----------------------------
-- Records of `easy_ads`
-- -----------------------------
INSERT INTO `easy_ads` VALUES ('1', 'HOME_PAGE_AD1', '首页广告1', '', '', '', '1');
INSERT INTO `easy_ads` VALUES ('4', '32', '123', '121', '/Uploads/Picture/Ads/1452758776_3628673.png', '111', '0');

-- -----------------------------
-- Table structure for `easy_article`
-- -----------------------------
DROP TABLE IF EXISTS `easy_article`;
;

-- -----------------------------
-- Records of `easy_article`
-- -----------------------------
INSERT INTO `easy_article` VALUES ('2', '62', '啦啦啦', '的的 啊啊 打法', '1452576517', '阿萨德发送到', '内容ad司法所地方<img src=\"./Uploads/Article/day_160112/201601121328183481.JPG\" width=\"600\" alt=\"\" />', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('3', '63', '图片类型', '图片类型', '1452873717', '图片类型', '<img src=\"./Uploads/Article/day_160117/201601171748248585.jpg\" alt=\"\" />					', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('4', '62', 'fasd', 'fasd', '1453010760', 'fads', 'fasd', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('5', '62', 'dsad', 'dsds', '1453011069', 'dfsa', 'fads', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('6', '62', '123123', 'fdsa', '1453011407', 'fads', '', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('7', '62', '42332', '432', '1453011555', '432432', '', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('8', '62', 'qffdsssdffds', 'fdsfdsds', '1453011615', 'fsdfd', 'sfd', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('9', '62', '234243', '432432', '1453011931', '432423', '324324', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('10', '62', 're', 'rew', '1453037500', 'rew', '', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('11', '62', 'gdsf', 'gsdf', '1453037511', 'gdsf', '', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('12', '62', 'gsf', 'gsf', '1453037521', 'dsff', 'fg', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('13', '62', 'fdas', 'fasd', '1453626964', 'fdas', '', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('14', '62', '8978979', 'hkjk', '1453627721', 'yiyyuiy', '', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('15', '62', 'fasd', 'fads', '1453630071', 'fads', '', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('16', '62', 'rwrew', 'rewrew', '1453630087', 'rewrew', 'rew', '0', '0', '1', '0', '0', '0');

-- -----------------------------
-- Table structure for `easy_category`
-- -----------------------------
DROP TABLE IF EXISTS `easy_category`;
;

-- -----------------------------
-- Records of `easy_category`
-- -----------------------------
INSERT INTO `easy_category` VALUES ('62', 'tokidoki世界', '0', '100', '0', '1', '1', '0');
INSERT INTO `easy_category` VALUES ('63', '分类2', '0', '100', '1', '0', '1', '0');

-- -----------------------------
-- Table structure for `easy_comment`
-- -----------------------------
DROP TABLE IF EXISTS `easy_comment`;
;


-- -----------------------------
-- Table structure for `easy_coupon`
-- -----------------------------
DROP TABLE IF EXISTS `easy_coupon`;
;

-- -----------------------------
-- Records of `easy_coupon`
-- -----------------------------
INSERT INTO `easy_coupon` VALUES ('0000000018', '11', '3', '8', '2016-01-02', '2016-01-29', '1', '1454078905', '1454079639');
INSERT INTO `easy_coupon` VALUES ('0000000019', '', '', '0', '2016-01-13', '2016-02-06', '0', '1454145506', '1454145506');
INSERT INTO `easy_coupon` VALUES ('0000000020', '243', '234', '432', '2016-01-05', '2016-01-27', '0', '1454160319', '1454160319');

-- -----------------------------
-- Table structure for `easy_fields`
-- -----------------------------
DROP TABLE IF EXISTS `easy_fields`;
;

-- -----------------------------
-- Records of `easy_fields`
-- -----------------------------
INSERT INTO `easy_fields` VALUES ('1', 'title', '这是一个默认网站标题', '1');
INSERT INTO `easy_fields` VALUES ('2', 'description', '这是一个默认网站描述', '1');
INSERT INTO `easy_fields` VALUES ('3', 'copyright', '这是一个默认网站版权', '1');
INSERT INTO `easy_fields` VALUES ('4', 'announcement', '这是站点公告哦', '1');
INSERT INTO `easy_fields` VALUES ('5', 'ad', '啦啦啦广告', '1');

-- -----------------------------
-- Table structure for `easy_link`
-- -----------------------------
DROP TABLE IF EXISTS `easy_link`;
;

-- -----------------------------
-- Records of `easy_link`
-- -----------------------------
INSERT INTO `easy_link` VALUES ('1', '1', 'http://www.baidu.com', '1');

-- -----------------------------
-- Table structure for `easy_lotteryaudit`
-- -----------------------------
DROP TABLE IF EXISTS `easy_lotteryaudit`;
;

-- -----------------------------
-- Records of `easy_lotteryaudit`
-- -----------------------------
INSERT INTO `easy_lotteryaudit` VALUES ('3', '11', 'fdas', '12', '21');

-- -----------------------------
-- Table structure for `easy_lotterytype`
-- -----------------------------
DROP TABLE IF EXISTS `easy_lotterytype`;
;

-- -----------------------------
-- Records of `easy_lotterytype`
-- -----------------------------
INSERT INTO `easy_lotterytype` VALUES ('1', '1231rew', 'fasdfdrew', '3242432', '1454159755', '1454160072');
INSERT INTO `easy_lotterytype` VALUES ('5', 'fdas', 'fdsa', '231', '1454160106', '1454160106');

-- -----------------------------
-- Table structure for `easy_member_user`
-- -----------------------------
DROP TABLE IF EXISTS `easy_member_user`;
;

-- -----------------------------
-- Records of `easy_member_user`
-- -----------------------------
INSERT INTO `easy_member_user` VALUES ('11', 'testtest', '13221312', '2016-01-12', '13221312', '13221312', '12', '13221312', '', '13221312', '1453629831', '1453629851', '0');
INSERT INTO `easy_member_user` VALUES ('10', '78678', '243', '2016-01-05', '432324', '0', '123', 'yuiyui', '', '很快就好看', '1453627335', '1453643662', '0');
INSERT INTO `easy_member_user` VALUES ('9', '111', '1111', '2016-01-20', '1111', '111', '312', '111', '', '111', '1453627193', '1453627193', '0');

-- -----------------------------
-- Table structure for `easy_news`
-- -----------------------------
DROP TABLE IF EXISTS `easy_news`;
;

-- -----------------------------
-- Records of `easy_news`
-- -----------------------------
INSERT INTO `easy_news` VALUES ('5', 'test', 'testtesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttest', '1453640735', '1453640735');

-- -----------------------------
-- Table structure for `easy_node`
-- -----------------------------
DROP TABLE IF EXISTS `easy_node`;
;


-- -----------------------------
-- Table structure for `easy_order`
-- -----------------------------
DROP TABLE IF EXISTS `easy_order`;
;

-- -----------------------------
-- Records of `easy_order`
-- -----------------------------
INSERT INTO `easy_order` VALUES ('5', '11', 'shouhuoren', '1231321', '34424arsrfsafdfajiuiul', '9', '234432', '342', '1454148137');

-- -----------------------------
-- Table structure for `easy_plugin`
-- -----------------------------
DROP TABLE IF EXISTS `easy_plugin`;
;

-- -----------------------------
-- Records of `easy_plugin`
-- -----------------------------
INSERT INTO `easy_plugin` VALUES ('7', 'Baidushare', '无', 'Index/Baidushare/info', '0', '0');

-- -----------------------------
-- Table structure for `easy_product`
-- -----------------------------
DROP TABLE IF EXISTS `easy_product`;
;

-- -----------------------------
-- Records of `easy_product`
-- -----------------------------
INSERT INTO `easy_product` VALUES ('6', '产品1', '234324', '<img src=\"./Uploads/Article/day_160127/201601272214538620.jpg\" alt=\"\" />342										', '342342', '34234232', 'shortdescriptjion', 'desccrition托尔斯泰', '1453818928', '1454072284');
INSERT INTO `easy_product` VALUES ('8', '453543', '43', '<img src=\"./Uploads/Article/day_160127/201601272214203750.png\" alt=\"\" />										', '43', '453', 'shortdescrition4324', 'descrition432423', '1453819266', '1454071594');
INSERT INTO `easy_product` VALUES ('9', 'test', '3', '', '4', '5', '中华人民共和国中华人民共和国中华人民共和国', '中华人民共和国中华人民共和国中华', '1454072253', '1454072270');

-- -----------------------------
-- Table structure for `easy_recommendation`
-- -----------------------------
DROP TABLE IF EXISTS `easy_recommendation`;
;

-- -----------------------------
-- Records of `easy_recommendation`
-- -----------------------------
INSERT INTO `easy_recommendation` VALUES ('3', '434341111111111', '<img src=\"./Uploads/Article/day_160117/201601171739229200.jpg\" alt=\"\" />																														', '', '54365564534', '12', '1453023565', '0');
INSERT INTO `easy_recommendation` VALUES ('4', 'fsad', '<img src=\"./Uploads/Article/day_160117/201601171815255969.jpg\" alt=\"\" />															', '', 'fdsafdsa', '1', '1453025729', '1');
INSERT INTO `easy_recommendation` VALUES ('7', '3', '', '', 'qqqqzzzzzzzzfdsaaaaaaaaaaaaaaa', '0', '1453036792', '0');
INSERT INTO `easy_recommendation` VALUES ('8', '4', '', '', 'qqqqzzzzzzzzfdsaaaaaaaaaaaaaaa', '0', '1453036797', '1');
INSERT INTO `easy_recommendation` VALUES ('9', '5', '', '', 'qqqqzzzzzzzzfdsaaaaaaaaaaaaaaa', '0', '1453036803', '0');
INSERT INTO `easy_recommendation` VALUES ('10', '6', '', '', 'qqqqzzzzzzzzfdsaaaaaaaaaaaaaaa', '0', '1453036810', '0');
INSERT INTO `easy_recommendation` VALUES ('11', '7', '', '', 'qqqqzzzzzzzzfdsaaaaaaaaaaaaaaa', '0', '1453036816', '0');
INSERT INTO `easy_recommendation` VALUES ('12', '8', '', '', 'qqqqzzzzzzzzfdsaaaaaaaaaaaaaaa', '0', '1453036822', '1');
INSERT INTO `easy_recommendation` VALUES ('13', '9', '', '', 'qqqqzzzzzzzzfdsaaaaaaaaaaaaaaa', '0', '1453036827', '1');
INSERT INTO `easy_recommendation` VALUES ('14', '12', '', '', 'qqqqzzzzzzzzfdsaaaaaaaaaaaaaaa', '0', '1453036833', '0');
INSERT INTO `easy_recommendation` VALUES ('15', '123', '', '', 'qqqqzzzzzzzzfdsaaaaaaaaaaaaaaa', '0', '1453036838', '0');
INSERT INTO `easy_recommendation` VALUES ('16', '43234243', '342', '342432432', 'qqqqzzzzzzzzfdsaaaaaaaaaaaaaaa', '342432', '1453629051', '0');

-- -----------------------------
-- Table structure for `easy_recompos`
-- -----------------------------
DROP TABLE IF EXISTS `easy_recompos`;
;

-- -----------------------------
-- Records of `easy_recompos`
-- -----------------------------
INSERT INTO `easy_recompos` VALUES ('2', 'qqqqzzzzzzzzfdsaaaaaaaaaaaaaaa', 'qqqqqqqfdsaaaaaaa');
INSERT INTO `easy_recompos` VALUES ('4', '54365564534', '423543');
INSERT INTO `easy_recompos` VALUES ('8', 'fdsafdsa', 'dfsafdsa');
INSERT INTO `easy_recompos` VALUES ('10', '54356', '5435');
INSERT INTO `easy_recompos` VALUES ('11', '4324312', '3421');
INSERT INTO `easy_recompos` VALUES ('12', '1', '1');
INSERT INTO `easy_recompos` VALUES ('14', '2', '1');
INSERT INTO `easy_recompos` VALUES ('15', '3', '3');
INSERT INTO `easy_recompos` VALUES ('16', '4', '4');
INSERT INTO `easy_recompos` VALUES ('17', '5', '5');
INSERT INTO `easy_recompos` VALUES ('18', '6', '6');
INSERT INTO `easy_recompos` VALUES ('19', '7', '7');
INSERT INTO `easy_recompos` VALUES ('20', '8', '8');
INSERT INTO `easy_recompos` VALUES ('21', '9', '9');
INSERT INTO `easy_recompos` VALUES ('22', '10', '10');
INSERT INTO `easy_recompos` VALUES ('23', '11', '11');
INSERT INTO `easy_recompos` VALUES ('24', '12', '12');
INSERT INTO `easy_recompos` VALUES ('25', '13', '133');
INSERT INTO `easy_recompos` VALUES ('26', '14', '14');
INSERT INTO `easy_recompos` VALUES ('27', '15', '15');

-- -----------------------------
-- Table structure for `easy_role`
-- -----------------------------
DROP TABLE IF EXISTS `easy_role`;
;


-- -----------------------------
-- Table structure for `easy_role_user`
-- -----------------------------
DROP TABLE IF EXISTS `easy_role_user`;
;


-- -----------------------------
-- Table structure for `easy_scoreaudit`
-- -----------------------------
DROP TABLE IF EXISTS `easy_scoreaudit`;
;

-- -----------------------------
-- Records of `easy_scoreaudit`
-- -----------------------------
INSERT INTO `easy_scoreaudit` VALUES ('1', '11', 'login', '0', '0');
INSERT INTO `easy_scoreaudit` VALUES ('3', '9', 'buy', '11', '11');

-- -----------------------------
-- Table structure for `easy_scoreproduct`
-- -----------------------------
DROP TABLE IF EXISTS `easy_scoreproduct`;
;

-- -----------------------------
-- Records of `easy_scoreproduct`
-- -----------------------------
INSERT INTO `easy_scoreproduct` VALUES ('4', '8', '32489', '7897', '32478', '2016-01-28', '2016-01-30', '1454145693', '1454146169');
INSERT INTO `easy_scoreproduct` VALUES ('5', '9', '787', '7987', '987', '2016-01-13', '2016-01-28', '1454146197', '1454146197');

-- -----------------------------
-- Table structure for `easy_scoretype`
-- -----------------------------
DROP TABLE IF EXISTS `easy_scoretype`;
;

-- -----------------------------
-- Records of `easy_scoretype`
-- -----------------------------
INSERT INTO `easy_scoretype` VALUES ('3', '312', '132', '312', '213', '231');
INSERT INTO `easy_scoretype` VALUES ('7', '321', '321', '321', '1453727950', '1453727950');
INSERT INTO `easy_scoretype` VALUES ('9', '32132', '312', '231', '1453727965', '1453727965');
INSERT INTO `easy_scoretype` VALUES ('13', '4324321432qrerwqe', '41324312io', '8', '1453728080', '1453728425');
INSERT INTO `easy_scoretype` VALUES ('14', 'buy', '买', '231123', '1453728544', '1453734378');
INSERT INTO `easy_scoretype` VALUES ('15', 'login', '登录', '10', '1453728568', '1453728568');

-- -----------------------------
-- Table structure for `easy_user`
-- -----------------------------
DROP TABLE IF EXISTS `easy_user`;
;

-- -----------------------------
-- Records of `easy_user`
-- -----------------------------
INSERT INTO `easy_user` VALUES ('6', 'admin', '21232f297a57a5a743894a0e4a801fc3', '1454143839', '0.0.0.0', '0');

-- -----------------------------
-- Table structure for `easy_wechat`
-- -----------------------------
DROP TABLE IF EXISTS `easy_wechat`;
;

-- -----------------------------
-- Records of `easy_wechat`
-- -----------------------------
INSERT INTO `easy_wechat` VALUES ('312', 'openid', 'token', 'refreshtoken', 'nickname', 'photosrc', '1221', '12312', '321213');
