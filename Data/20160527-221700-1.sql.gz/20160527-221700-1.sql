-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : simpsons
-- 
-- Part : #1
-- Date : 2016-05-27 22:17:00
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `easy_access`
-- -----------------------------
DROP TABLE IF EXISTS `easy_access`;
;


-- -----------------------------
-- Table structure for `easy_ads`
-- -----------------------------
DROP TABLE IF EXISTS `easy_ads`;
;

-- -----------------------------
-- Records of `easy_ads`
-- -----------------------------
INSERT INTO `easy_ads` VALUES ('1', 'HOME_PAGE_AD1', '首页广告1', '', '', '', '1');
INSERT INTO `easy_ads` VALUES ('4', '32', '123', '121', '/Uploads/Picture/Ads/1452758776_3628673.png', '111', '0');

-- -----------------------------
-- Table structure for `easy_article`
-- -----------------------------
DROP TABLE IF EXISTS `easy_article`;
;

-- -----------------------------
-- Records of `easy_article`
-- -----------------------------
INSERT INTO `easy_article` VALUES ('2', '62', '啦啦啦', '的的 啊啊 打法', '1452576517', '阿萨德发送到', '内容ad司法所地方<img src=\"./Uploads/Article/day_160112/201601121328183481.JPG\" width=\"600\" alt=\"\" />', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('3', '63', '图片类型', '图片类型', '1452873717', '图片类型', '<img src=\"./Uploads/Article/day_160117/201601171748248585.jpg\" alt=\"\" />					', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('4', '62', 'fasd', 'fasd', '1453010760', 'fads', 'fasd', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('5', '62', 'dsad', 'dsds', '1453011069', 'dfsa', 'fads', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('6', '62', '123123', 'fdsa', '1453011407', 'fads', '', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('7', '62', '42332', '432', '1453011555', '432432', '', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('8', '62', 'qffdsssdffds', 'fdsfdsds', '1453011615', 'fsdfd', 'sfd', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('9', '62', '234243', '432432', '1453011931', '432423', '324324', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('10', '62', 're', 'rew', '1453037500', 'rew', '', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('11', '62', 'gdsf', 'gsdf', '1453037511', 'gdsf', '', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('12', '62', 'gsf', 'gsf', '1453037521', 'dsff', 'fg', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('13', '62', 'fdas', 'fasd', '1453626964', 'fdas', '', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('14', '62', '8978979', 'hkjk', '1453627721', 'yiyyuiy', '', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('15', '62', 'fasd', 'fads', '1453630071', 'fads', '', '0', '0', '1', '0', '0', '0');
INSERT INTO `easy_article` VALUES ('16', '62', 'rwrew', 'rewrew', '1453630087', 'rewrew', 'rew', '0', '0', '1', '0', '0', '0');

-- -----------------------------
-- Table structure for `easy_category`
-- -----------------------------
DROP TABLE IF EXISTS `easy_category`;
;

-- -----------------------------
-- Records of `easy_category`
-- -----------------------------
INSERT INTO `easy_category` VALUES ('62', 'tokidoki世界', '0', '100', '0', '1', '1', '0');
INSERT INTO `easy_category` VALUES ('63', '分类2', '0', '100', '1', '0', '1', '0');

-- -----------------------------
-- Table structure for `easy_comment`
-- -----------------------------
DROP TABLE IF EXISTS `easy_comment`;
;


-- -----------------------------
-- Table structure for `easy_coupon`
-- -----------------------------
DROP TABLE IF EXISTS `easy_coupon`;
;

-- -----------------------------
-- Records of `easy_coupon`
-- -----------------------------
INSERT INTO `easy_coupon` VALUES ('0000000084', '14583891121200', '62', '99', '满500可用', '2016-03-09', '2016-03-23', '0', '1458389112', '1458389112');
INSERT INTO `easy_coupon` VALUES ('0000000085', '14583902666107', '62', '99', '满500可用', '2016-03-09', '2016-03-23', '0', '1458390266', '1458390266');
INSERT INTO `easy_coupon` VALUES ('0000000086', '14583904499728', '62', '99', '满300可用', '2016-03-09', '2016-03-23', '0', '1458390449', '1458390449');
INSERT INTO `easy_coupon` VALUES ('0000000087', '14583989496827', '62', '99', '满50可用', '2016-03-09', '2016-03-23', '0', '1458398949', '1458398949');
INSERT INTO `easy_coupon` VALUES ('0000000088', '14584089502507', '62', '99', '500', '2016-03-09', '2016-03-23', '1', '1458408950', '1461165187');
INSERT INTO `easy_coupon` VALUES ('0000000089', '14584095862862', '62', '99', '500', '2016-03-09', '2016-03-23', '0', '1458409586', '1458409586');
INSERT INTO `easy_coupon` VALUES ('0000000090', '14584098951820', '62', '99', '500', '2016-03-09', '2016-03-23', '1', '1458409895', '1458409895');
INSERT INTO `easy_coupon` VALUES ('0000000091', '14584101497084', '62', '50', '满300可用', '2016-03-09', '2016-03-23', '1', '1458410149', '1458410149');
INSERT INTO `easy_coupon` VALUES ('0000000092', '14584102236905', '62', '50', '满300可用', '2016-03-09', '2016-03-23', '1', '1458410223', '1458410223');
INSERT INTO `easy_coupon` VALUES ('0000000093', '14584102315358', '62', '50', '满300可用', '2016-03-09', '2016-03-23', '1', '1458410231', '1461164201');
INSERT INTO `easy_coupon` VALUES ('0000000094', '14584102881032', '62', '50', '满300可用', '2016-03-09', '2016-03-23', '1', '1458410288', '1461165181');
INSERT INTO `easy_coupon` VALUES ('0000000095', '14584102935167', '62', '50', '满300可用', '2016-03-09', '2016-03-23', '1', '1458410293', '1458410293');
INSERT INTO `easy_coupon` VALUES ('0000000096', '14584103867951', '62', '50', '满300可用', '2016-03-09', '2016-03-23', '0', '1458410386', '1458410386');
INSERT INTO `easy_coupon` VALUES ('0000000097', '14584103922487', '62', '50', '满300可用', '2016-03-09', '2016-03-23', '1', '1458410392', '1461164192');
INSERT INTO `easy_coupon` VALUES ('0000000098', '14584105461593', '62', '50', '满300可用', '2016-03-09', '2016-03-23', '1', '1458410546', '1458410546');
INSERT INTO `easy_coupon` VALUES ('0000000099', '14584654648585', '62', '50', '满300可用', '2016-03-09', '2016-03-23', '1', '1458465464', '1458465464');

-- -----------------------------
-- Table structure for `easy_coupontype`
-- -----------------------------
DROP TABLE IF EXISTS `easy_coupontype`;
;

-- -----------------------------
-- Records of `easy_coupontype`
-- -----------------------------
INSERT INTO `easy_coupontype` VALUES ('7', '500', '满1000可用', '', '', '1459053328', '1459053328', '优惠券1');

-- -----------------------------
-- Table structure for `easy_fields`
-- -----------------------------
DROP TABLE IF EXISTS `easy_fields`;
;

-- -----------------------------
-- Records of `easy_fields`
-- -----------------------------
INSERT INTO `easy_fields` VALUES ('1', 'title', 'Simpson', '1');
INSERT INTO `easy_fields` VALUES ('2', 'description', '辛普森网站', '1');
INSERT INTO `easy_fields` VALUES ('3', 'copyright', '辛普森', '1');
INSERT INTO `easy_fields` VALUES ('4', 'announcement', '这是站点公告哦', '1');
INSERT INTO `easy_fields` VALUES ('5', 'ad', '广告<span style=\"font-size: 13.3333px;\">广告</span><span style=\"font-size: 13.3333px;\">广告</span><span style=\"font-size: 13.3333px;\">广告</span><span style=\"font-size: 13.3333px;\">广告</span><span style=\"font-size: 13.3333px;\">广告</span><span style=\"font-size: 13.3333px;\">广告</span><span style=\"font-size: 13.3333px;\">广告</span><span style=\"font-size: 13.3333px;\">广告</span><span style=\"font-size: 13.3333px;\">广告</span><span style=\"font-size: 13.3333px;\">广告</span><span style=\"font-size: 13.3333px;\">广告</span><span style=\"font-size: 13.3333px;\">广告</span><span style=\"font-size: 13.3333px;\">广告</span><span style=\"font-size: 13.3333px;\">广告</span><span style=\"font-size: 13.3333px;\">广告</span><span style=\"font-size: 13.3333px;\">广告</span><span style=\"font-size: 13.3333px;\">广告</span><span style=\"font-size: 13.3333px;\">广告</span><span style=\"font-size: 13.3333px;\">广告</span><span style=\"font-size: 13.3333px;\">广告</span><span style=\"font-size: 13.3333px;\">广告</span><span style=\"font-size: 13.3333px;\">广告</span><span style=\"font-size: 13.3333px;\">广告</span>', '1');

-- -----------------------------
-- Table structure for `easy_friendscoreaudit`
-- -----------------------------
DROP TABLE IF EXISTS `easy_friendscoreaudit`;
;


-- -----------------------------
-- Table structure for `easy_link`
-- -----------------------------
DROP TABLE IF EXISTS `easy_link`;
;

-- -----------------------------
-- Records of `easy_link`
-- -----------------------------
INSERT INTO `easy_link` VALUES ('1', 'Simpson', 'http://www.baidu.com', '0');

-- -----------------------------
-- Table structure for `easy_lotteryaudit`
-- -----------------------------
DROP TABLE IF EXISTS `easy_lotteryaudit`;
;

-- -----------------------------
-- Records of `easy_lotteryaudit`
-- -----------------------------
INSERT INTO `easy_lotteryaudit` VALUES ('559', '62', 'redpacket', 'one', '2', '无', '1', '', '', '1458919772', '1458919772');

-- -----------------------------
-- Table structure for `easy_lotterytype`
-- -----------------------------
DROP TABLE IF EXISTS `easy_lotterytype`;
;

-- -----------------------------
-- Records of `easy_lotterytype`
-- -----------------------------
INSERT INTO `easy_lotterytype` VALUES ('12', 'coupontype', '优惠券1', '100', '1459053337', '1459053337');

-- -----------------------------
-- Table structure for `easy_member_user`
-- -----------------------------
DROP TABLE IF EXISTS `easy_member_user`;
;

-- -----------------------------
-- Records of `easy_member_user`
-- -----------------------------
INSERT INTO `easy_member_user` VALUES ('62', '', '18818203641', '', '浦东新区', '87135', '', ' OPENID', 'http://wx.qlogo.cn/mmopen/g3MonUZtNHkdmzicIlibx6iaFqAc56vxLSUfpb6n5WKSYVY0ChQKkiaJSgQ1dZuTOgvLLrhJbE', 'NICKNAME', '1458391790', '1461249409', '0');

-- -----------------------------
-- Table structure for `easy_news`
-- -----------------------------
DROP TABLE IF EXISTS `easy_news`;
;

-- -----------------------------
-- Records of `easy_news`
-- -----------------------------
INSERT INTO `easy_news` VALUES ('5', 'test', '<img src=\"./Uploads/Article/day_160201/201602012249561579.jpg\" alt=\"\" />testtesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttest																				', '1453640735', '1454338294');
INSERT INTO `easy_news` VALUES ('6', '123321', '<img src=\"./Uploads/Article/day_160201/201602012252293849.jpg\" alt=\"\" width=\"60\" height=\"60\" />fsdfdsfsdafdsafdsafsda																														', '1454338262', '1454338377');
INSERT INTO `easy_news` VALUES ('7', 'trewtrewtrew', '<strong><em><span style=\"font-size:10px;\">fdsasaaaaaaaaaaaaaaaaaaaaaaaaaa					</span></em></strong>					', '1454338438', '1458995196');

-- -----------------------------
-- Table structure for `easy_node`
-- -----------------------------
DROP TABLE IF EXISTS `easy_node`;
;


-- -----------------------------
-- Table structure for `easy_order`
-- -----------------------------
DROP TABLE IF EXISTS `easy_order`;
;

-- -----------------------------
-- Records of `easy_order`
-- -----------------------------
INSERT INTO `easy_order` VALUES ('38', '62', 'NICKNAME', '18818203641', '重庆市 重庆市 重庆市', '浦东新区', '14', 'product', '大不列颠', '5000', '1', '1', '', '1458570256', '1458570256', 'PB1458570256998', '', '', '');
INSERT INTO `easy_order` VALUES ('39', '62', 'NICKNAME', '18818203641', '天津市 天津市 天津市', '浦东新区', '12', 'scoreproduct', '兑换商品', '400', '1', '1', '', '1458570298', '1458570298', 'PE1458570298192', '', '', '');
INSERT INTO `easy_order` VALUES ('40', '62', 'NICKNAME', '18818203641', '', '浦东新区', '12', 'scoreproduct', '兑换商品', '400', '1', '1', '', '1458570393', '1458570393', 'PE1458570393523', '', '', '');
INSERT INTO `easy_order` VALUES ('41', '62', '8888888888', '18818203641', '', '浦东新区', '14', 'product', '大不列颠', '5000', '1', '1', '', '1458653926', '1458924051', 'PB1458653926439', '', '', '');
INSERT INTO `easy_order` VALUES ('44', '62', '5675', '18818203641', '789798978897', '浦东新区', '14', 'product', '大不列颠', '5000', '1', '2', '', '1458654029', '1459261977', 'PB1458654029674', '', '', '');

-- -----------------------------
-- Table structure for `easy_plugin`
-- -----------------------------
DROP TABLE IF EXISTS `easy_plugin`;
;

-- -----------------------------
-- Records of `easy_plugin`
-- -----------------------------
INSERT INTO `easy_plugin` VALUES ('7', 'Baidushare', '无', 'Index/Baidushare/info', '0', '0');

-- -----------------------------
-- Table structure for `easy_product`
-- -----------------------------
DROP TABLE IF EXISTS `easy_product`;
;

-- -----------------------------
-- Records of `easy_product`
-- -----------------------------
INSERT INTO `easy_product` VALUES ('14', '大不列颠', '5000', '/Uploads/Product//1458136906.png', '50', '大不列颠大不列颠大不列颠大不列颠大不列颠大不列颠大不列颠大不列颠大不列颠大不列颠大不列颠大不列颠大不列颠大不列颠大不列颠大不列颠大不列颠大不列颠', '大不列颠大不列颠大不列颠大不列颠大不列颠大不列颠大不列颠大不列颠大不列颠大不列颠大不列颠', '1458136906', '1458136906', '0');
INSERT INTO `easy_product` VALUES ('15', '睡衣', '344', '/Uploads/Product//1458137272.png', '34', '睡衣睡衣睡衣睡衣', '睡衣睡衣睡衣睡衣睡衣睡衣', '1458137272', '1458137272', '0');
INSERT INTO `easy_product` VALUES ('18', '423423', '432', '/Uploads/Product//1458146739.png', '432', '432', '432', '1458146739', '1458146739', '0');
INSERT INTO `easy_product` VALUES ('19', 'testetts', '2332.98', '/Uploads/Product/19/1458224838.png', '32', '324432', 'testettstestettstestettstestettstestettstestettstestettstestettstestettstestettstestettstestettstestettstestetts', '1458224726', '1458656252', '0');

-- -----------------------------
-- Table structure for `easy_productimglib`
-- -----------------------------
DROP TABLE IF EXISTS `easy_productimglib`;
;

-- -----------------------------
-- Records of `easy_productimglib`
-- -----------------------------
INSERT INTO `easy_productimglib` VALUES ('9', '9', './Uploads/Product9/1454507360.jpg', '1454507360', '1454507360');
INSERT INTO `easy_productimglib` VALUES ('10', '9', './Uploads/Product9/1454507860.jpg', '1454507860', '1454507860');
INSERT INTO `easy_productimglib` VALUES ('12', '9', './Uploads/Product', '1454508028', '1454508028');
INSERT INTO `easy_productimglib` VALUES ('13', '9', './Uploads/Product', '1454508670', '1454508670');
INSERT INTO `easy_productimglib` VALUES ('65', '10', './Uploads/Product/10/1454594297.jpg', '1454594297', '1454594297');
INSERT INTO `easy_productimglib` VALUES ('66', '10', './Uploads/Product/10/1454594912.jpg', '1454594912', '1454594912');
INSERT INTO `easy_productimglib` VALUES ('67', '10', './Uploads/Product/10/1454595012.jpg', '1454595012', '1454595012');
INSERT INTO `easy_productimglib` VALUES ('68', '10', './Uploads/Product/10/1454595091.jpg', '1454595091', '1454595091');
INSERT INTO `easy_productimglib` VALUES ('69', '10', './Uploads/Product/10/1454595128.jpg', '1454595128', '1454595128');
INSERT INTO `easy_productimglib` VALUES ('70', '10', './Uploads/Product/10/1454595244.jpg', '1454595244', '1454595244');
INSERT INTO `easy_productimglib` VALUES ('71', '10', './Uploads/Product/10/1454595356.jpg', '1454595356', '1454595356');
INSERT INTO `easy_productimglib` VALUES ('72', '10', './Uploads/Product/10/1454595715.jpg', '1454595715', '1454595715');
INSERT INTO `easy_productimglib` VALUES ('73', '10', './Uploads/Product/10/1454595732.jpg', '1454595732', '1454595732');
INSERT INTO `easy_productimglib` VALUES ('74', '10', './Uploads/Product/10/1454595776.jpg', '1454595776', '1454595776');
INSERT INTO `easy_productimglib` VALUES ('75', '10', './Uploads/Product/10/1454596063.jpg', '1454596063', '1454596063');
INSERT INTO `easy_productimglib` VALUES ('76', '10', './Uploads/Product/10/1454596342.jpg', '1454596342', '1454596342');
INSERT INTO `easy_productimglib` VALUES ('77', '10', './Uploads/Product/10/1454596491.jpg', '1454596491', '1454596491');
INSERT INTO `easy_productimglib` VALUES ('78', '10', './Uploads/Product/10/1454596852.jpg', '1454596852', '1454596852');
INSERT INTO `easy_productimglib` VALUES ('79', '10', './Uploads/Product/10/1454596855.jpg', '1454596855', '1454596855');
INSERT INTO `easy_productimglib` VALUES ('80', '10', './Uploads/Product/10/1454596857.jpg', '1454596857', '1454596857');
INSERT INTO `easy_productimglib` VALUES ('81', '10', './Uploads/Product/10/1454597056.jpg', '1454597056', '1454597056');
INSERT INTO `easy_productimglib` VALUES ('82', '10', './Uploads/Product/10/1454597087.jpg', '1454597087', '1454597087');
INSERT INTO `easy_productimglib` VALUES ('83', '10', './Uploads/Product/10/1454597097.jpg', '1454597097', '1454597097');
INSERT INTO `easy_productimglib` VALUES ('84', '10', './Uploads/Product/10/1454597694.jpg', '1454597694', '1454597694');
INSERT INTO `easy_productimglib` VALUES ('85', '10', './Uploads/Product/10/1454597708.jpg', '1454597708', '1454597899');
INSERT INTO `easy_productimglib` VALUES ('88', '10', '/Uploads/Product/10/1454599017.jpg', '1454599001', '1454599017');
INSERT INTO `easy_productimglib` VALUES ('89', '13', '/Uploads/Product/13/1457107925.png', '1457107915', '1457107925');
INSERT INTO `easy_productimglib` VALUES ('90', '13', '/Uploads/Product/13/1457108072.png', '1457108072', '1457108072');
INSERT INTO `easy_productimglib` VALUES ('91', '15', '/Uploads/Product/15/1458144865.png', '1458144865', '1458144865');
INSERT INTO `easy_productimglib` VALUES ('92', '15', '/Uploads/Product/15/1458145754.png', '1458145754', '1458145754');
INSERT INTO `easy_productimglib` VALUES ('93', '14', '/Uploads/Product/14/1458145866.png', '1458145866', '1458145866');
INSERT INTO `easy_productimglib` VALUES ('94', '19', './Uploads/Product/19/1459173265.png', '1459173265', '1459173265');

-- -----------------------------
-- Table structure for `easy_recommendation`
-- -----------------------------
DROP TABLE IF EXISTS `easy_recommendation`;
;

-- -----------------------------
-- Records of `easy_recommendation`
-- -----------------------------
INSERT INTO `easy_recommendation` VALUES ('3', '434341111111111', '<img src=\"./Uploads/Article/day_160117/201601171739229200.jpg\" alt=\"\" />																														', '', '54365564534', '12', '1453023565', '0');
INSERT INTO `easy_recommendation` VALUES ('4', 'fsad', '<img src=\"./Uploads/Article/day_160117/201601171815255969.jpg\" alt=\"\" />															', '', 'fdsafdsa', '1', '1453025729', '1');
INSERT INTO `easy_recommendation` VALUES ('7', '3', '', '', 'qqqqzzzzzzzzfdsaaaaaaaaaaaaaaa', '0', '1453036792', '0');
INSERT INTO `easy_recommendation` VALUES ('8', '4', '', '', 'qqqqzzzzzzzzfdsaaaaaaaaaaaaaaa', '0', '1453036797', '1');
INSERT INTO `easy_recommendation` VALUES ('9', '5', '', '', 'qqqqzzzzzzzzfdsaaaaaaaaaaaaaaa', '0', '1453036803', '0');
INSERT INTO `easy_recommendation` VALUES ('10', '6', '', '', 'qqqqzzzzzzzzfdsaaaaaaaaaaaaaaa', '0', '1453036810', '0');
INSERT INTO `easy_recommendation` VALUES ('11', '7', '', '', 'qqqqzzzzzzzzfdsaaaaaaaaaaaaaaa', '0', '1453036816', '0');
INSERT INTO `easy_recommendation` VALUES ('12', '8', '', '', 'qqqqzzzzzzzzfdsaaaaaaaaaaaaaaa', '0', '1453036822', '1');
INSERT INTO `easy_recommendation` VALUES ('13', '9', '', '', 'qqqqzzzzzzzzfdsaaaaaaaaaaaaaaa', '0', '1453036827', '1');
INSERT INTO `easy_recommendation` VALUES ('14', '12', '', '', 'qqqqzzzzzzzzfdsaaaaaaaaaaaaaaa', '0', '1453036833', '0');
INSERT INTO `easy_recommendation` VALUES ('15', '123', '', '', 'qqqqzzzzzzzzfdsaaaaaaaaaaaaaaa', '0', '1453036838', '0');
INSERT INTO `easy_recommendation` VALUES ('16', '43234243', '342', '342432432', 'qqqqzzzzzzzzfdsaaaaaaaaaaaaaaa', '342432', '1453629051', '0');

-- -----------------------------
-- Table structure for `easy_recompos`
-- -----------------------------
DROP TABLE IF EXISTS `easy_recompos`;
;

-- -----------------------------
-- Records of `easy_recompos`
-- -----------------------------
INSERT INTO `easy_recompos` VALUES ('2', 'qqqqzzzzzzzzfdsaaaaaaaaaaaaaaa', 'qqqqqqqfdsaaaaaaa');
INSERT INTO `easy_recompos` VALUES ('4', '54365564534', '423543');
INSERT INTO `easy_recompos` VALUES ('8', 'fdsafdsa', 'dfsafdsa');
INSERT INTO `easy_recompos` VALUES ('10', '54356', '5435');
INSERT INTO `easy_recompos` VALUES ('11', '4324312', '3421');
INSERT INTO `easy_recompos` VALUES ('12', '1', '1');
INSERT INTO `easy_recompos` VALUES ('14', '2', '1');
INSERT INTO `easy_recompos` VALUES ('15', '3', '3');
INSERT INTO `easy_recompos` VALUES ('16', '4', '4');
INSERT INTO `easy_recompos` VALUES ('17', '5', '5');
INSERT INTO `easy_recompos` VALUES ('18', '6', '6');
INSERT INTO `easy_recompos` VALUES ('19', '7', '7');
INSERT INTO `easy_recompos` VALUES ('20', '8', '8');
INSERT INTO `easy_recompos` VALUES ('21', '9', '9');
INSERT INTO `easy_recompos` VALUES ('22', '10', '10');
INSERT INTO `easy_recompos` VALUES ('23', '11', '11');
INSERT INTO `easy_recompos` VALUES ('24', '12', '12');
INSERT INTO `easy_recompos` VALUES ('25', '13', '133');
INSERT INTO `easy_recompos` VALUES ('26', '14', '14');
INSERT INTO `easy_recompos` VALUES ('27', '15', '15');

-- -----------------------------
-- Table structure for `easy_redpacket`
-- -----------------------------
DROP TABLE IF EXISTS `easy_redpacket`;
;

-- -----------------------------
-- Records of `easy_redpacket`
-- -----------------------------
INSERT INTO `easy_redpacket` VALUES ('1', 'tesre', '121', '', '', '', '1459051495', '1459051495');

-- -----------------------------
-- Table structure for `easy_role`
-- -----------------------------
DROP TABLE IF EXISTS `easy_role`;
;


-- -----------------------------
-- Table structure for `easy_role_user`
-- -----------------------------
DROP TABLE IF EXISTS `easy_role_user`;
;


-- -----------------------------
-- Table structure for `easy_scoreaudit`
-- -----------------------------
DROP TABLE IF EXISTS `easy_scoreaudit`;
;

-- -----------------------------
-- Records of `easy_scoreaudit`
-- -----------------------------
INSERT INTO `easy_scoreaudit` VALUES ('1', '11', 'login', '', '', 'ADD', '0', '0');
INSERT INTO `easy_scoreaudit` VALUES ('3', '9', 'buy', '', '', 'ADD', '11', '11');
INSERT INTO `easy_scoreaudit` VALUES ('4', '61', '抽奖', 'lottery', '1', 'ADD', '1458384475', '1458384475');
INSERT INTO `easy_scoreaudit` VALUES ('5', '61', '抽奖', 'lottery', '1', 'ADD', '1458385761', '1458385761');
INSERT INTO `easy_scoreaudit` VALUES ('6', '61', '抽奖', 'lottery', '1', 'ADD', '1458385765', '1458385765');
INSERT INTO `easy_scoreaudit` VALUES ('7', '61', '抽奖', 'lottery', '1', 'ADD', '1458385869', '1458385869');
INSERT INTO `easy_scoreaudit` VALUES ('8', '61', '抽奖', 'lottery', '1', 'ADD', '1458385874', '1458385874');
INSERT INTO `easy_scoreaudit` VALUES ('9', '61', '抽奖', 'lottery', '1', 'ADD', '1458385878', '1458385878');
INSERT INTO `easy_scoreaudit` VALUES ('10', '61', '抽奖', 'lottery', '1', 'ADD', '1458385884', '1458385884');
INSERT INTO `easy_scoreaudit` VALUES ('11', '61', '抽奖', 'lottery', '1', 'ADD', '1458389125', '1458389125');
INSERT INTO `easy_scoreaudit` VALUES ('12', '61', '抽奖', 'lottery', '1', 'ADD', '1458389850', '1458389850');
INSERT INTO `easy_scoreaudit` VALUES ('13', '61', '抽奖', 'lottery', '1', 'ADD', '1458390186', '1458390186');
INSERT INTO `easy_scoreaudit` VALUES ('14', '61', '抽奖', 'lottery', '1', 'ADD', '1458390275', '1458390275');
INSERT INTO `easy_scoreaudit` VALUES ('15', '61', '抽奖', 'lottery', '1', 'ADD', '1458390323', '1458390323');
INSERT INTO `easy_scoreaudit` VALUES ('16', '61', '抽奖', 'lottery', '1', 'ADD', '1458390340', '1458390340');
INSERT INTO `easy_scoreaudit` VALUES ('17', '61', '抽奖', 'lottery', '1', 'ADD', '1458390432', '1458390432');
INSERT INTO `easy_scoreaudit` VALUES ('18', '61', '抽奖', 'lottery', '1', 'ADD', '1458390453', '1458390453');
INSERT INTO `easy_scoreaudit` VALUES ('19', '62', '抽奖', 'lottery', '1', 'ADD', '1458395085', '1458395085');
INSERT INTO `easy_scoreaudit` VALUES ('20', '62', '抽奖', 'lottery', '1', 'ADD', '1458397999', '1458397999');
INSERT INTO `easy_scoreaudit` VALUES ('21', '62', '抽奖', 'lottery', '1', 'ADD', '1458398093', '1458398093');
INSERT INTO `easy_scoreaudit` VALUES ('22', '62', '抽奖', 'lottery', '1', 'ADD', '1458399178', '1458399178');
INSERT INTO `easy_scoreaudit` VALUES ('23', '62', '抽奖', 'lottery', '1', 'ADD', '1458399413', '1458399413');
INSERT INTO `easy_scoreaudit` VALUES ('24', '62', '抽奖', 'lottery', '1', 'ADD', '1458399854', '1458399854');
INSERT INTO `easy_scoreaudit` VALUES ('25', '62', '抽奖', 'lottery', '1', 'ADD', '1458403536', '1458403536');
INSERT INTO `easy_scoreaudit` VALUES ('26', '62', '抽奖', 'lottery', '1', 'ADD', '1458403974', '1458403974');
INSERT INTO `easy_scoreaudit` VALUES ('27', '62', '抽奖', 'lottery', '1', 'ADD', '1458408464', '1458408464');
INSERT INTO `easy_scoreaudit` VALUES ('28', '62', '抽奖', 'lottery', '1', 'ADD', '1458408621', '1458408621');
INSERT INTO `easy_scoreaudit` VALUES ('29', '62', '抽奖', 'lottery', '1', 'ADD', '1458408630', '1458408630');
INSERT INTO `easy_scoreaudit` VALUES ('30', '62', '抽奖', 'lottery', '1', 'ADD', '1458408634', '1458408634');
INSERT INTO `easy_scoreaudit` VALUES ('31', '62', '抽奖', 'lottery', '1', 'ADD', '1458408639', '1458408639');
INSERT INTO `easy_scoreaudit` VALUES ('32', '62', '抽奖', 'lottery', '1', 'ADD', '1458408882', '1458408882');
INSERT INTO `easy_scoreaudit` VALUES ('33', '62', '抽奖', 'lottery', '1', 'ADD', '1458408889', '1458408889');
INSERT INTO `easy_scoreaudit` VALUES ('34', '62', '抽奖', 'lottery', '1', 'ADD', '1458408965', '1458408965');
INSERT INTO `easy_scoreaudit` VALUES ('35', '62', '抽奖', 'lottery', '1', 'ADD', '1458409534', '1458409534');
INSERT INTO `easy_scoreaudit` VALUES ('36', '62', '抽奖', 'lottery', '3', 'ADD', '1458409591', '1458409591');
INSERT INTO `easy_scoreaudit` VALUES ('37', '62', '抽奖', 'lottery', '1', 'ADD', '1458409764', '1458409764');
INSERT INTO `easy_scoreaudit` VALUES ('38', '62', '抽奖', 'lottery', '4', 'ADD', '1458409773', '1458409773');
INSERT INTO `easy_scoreaudit` VALUES ('39', '62', '抽奖', 'lottery', '4', 'ADD', '1458410297', '1458410297');
INSERT INTO `easy_scoreaudit` VALUES ('40', '62', '抽奖', 'lottery', '5', 'ADD', '1458410305', '1458410305');
INSERT INTO `easy_scoreaudit` VALUES ('41', '62', '抽奖', 'lottery', '7', 'ADD', '1458410397', '1458410397');
INSERT INTO `easy_scoreaudit` VALUES ('42', '62', '抽奖', 'lottery', '7', 'ADD', '1458567364', '1458567364');
INSERT INTO `easy_scoreaudit` VALUES ('43', '62', '抽奖', 'lottery', '5', 'ADD', '1458737243', '1458737243');
INSERT INTO `easy_scoreaudit` VALUES ('44', '62', '抽奖', 'lottery', '5', 'ADD', '1458916587', '1458916587');

-- -----------------------------
-- Table structure for `easy_scoreproduct`
-- -----------------------------
DROP TABLE IF EXISTS `easy_scoreproduct`;
;

-- -----------------------------
-- Records of `easy_scoreproduct`
-- -----------------------------
INSERT INTO `easy_scoreproduct` VALUES ('12', '兑换商品', '400', '/Uploads/Scoreproduct//1458469894.png', '兑换商品', '兑换商品兑换商品兑换商品兑换商品兑换商品兑换商品兑换商品兑换商品兑换商品兑换商品', '0', '', '', '1458469894', '1458469894');
INSERT INTO `easy_scoreproduct` VALUES ('13', '兑换商品22', '41', '/Uploads/Scoreproduct//1458470090.png', '兑换商品22', '兑换商品22兑换商品22兑换商品22兑换商品22兑换商品22兑换商品22', '0', '', '', '1458470090', '1458476084');
INSERT INTO `easy_scoreproduct` VALUES ('14', 'duihuau33', '4999', '/Uploads/Scoreproduct//1458481629.png', '21321', '31221321', '21', '', '', '1458481546', '1458481629');

-- -----------------------------
-- Table structure for `easy_scoreproductimglib`
-- -----------------------------
DROP TABLE IF EXISTS `easy_scoreproductimglib`;
;

-- -----------------------------
-- Records of `easy_scoreproductimglib`
-- -----------------------------
INSERT INTO `easy_scoreproductimglib` VALUES ('1', '0', '0', '1457106618', '1457106618');
INSERT INTO `easy_scoreproductimglib` VALUES ('2', '0', '0', '1457106961', '1457106961');
INSERT INTO `easy_scoreproductimglib` VALUES ('3', '0', '0', '1457107208', '1457107208');
INSERT INTO `easy_scoreproductimglib` VALUES ('4', '0', '0', '1457107341', '1457107341');
INSERT INTO `easy_scoreproductimglib` VALUES ('8', '7', '0', '1457107720', '1457107720');
INSERT INTO `easy_scoreproductimglib` VALUES ('11', '7', '0', '1457108017', '1457108017');
INSERT INTO `easy_scoreproductimglib` VALUES ('12', '4', '0', '1457108036', '1457108036');
INSERT INTO `easy_scoreproductimglib` VALUES ('14', '11', '/Uploads/Scoreproduct/11/1457108611.png', '1457108213', '1457108611');
INSERT INTO `easy_scoreproductimglib` VALUES ('17', '11', '/Uploads/Scoreproduct/11/1457108591.jpg', '1457108591', '1457108591');
INSERT INTO `easy_scoreproductimglib` VALUES ('18', '6', '/Uploads/Scoreproduct/6/1457108623.jpg', '1457108623', '1457108623');
INSERT INTO `easy_scoreproductimglib` VALUES ('19', '13', '/Uploads/Scoreproduct/13/1458470102.png', '1458470102', '1458470102');
INSERT INTO `easy_scoreproductimglib` VALUES ('20', '13', '/Uploads/Scoreproduct/13/1458470111.png', '1458470111', '1458470111');
INSERT INTO `easy_scoreproductimglib` VALUES ('21', '13', '/Uploads/Scoreproduct/13/1458470118.png', '1458470118', '1458470118');

-- -----------------------------
-- Table structure for `easy_scoretype`
-- -----------------------------
DROP TABLE IF EXISTS `easy_scoretype`;
;

-- -----------------------------
-- Records of `easy_scoretype`
-- -----------------------------
INSERT INTO `easy_scoretype` VALUES ('7', 'rwe', '', '12', '312', '0', '1459053041', '1459053041');
INSERT INTO `easy_scoretype` VALUES ('8', '登录', '', '199', '12130', '0', '1459174155', '1459174438');

-- -----------------------------
-- Table structure for `easy_user`
-- -----------------------------
DROP TABLE IF EXISTS `easy_user`;
;

-- -----------------------------
-- Records of `easy_user`
-- -----------------------------
INSERT INTO `easy_user` VALUES ('6', 'admin', '21232f297a57a5a743894a0e4a801fc3', '1464358611', '0.0.0.0', '0', '1457109927', '1457109927');
INSERT INTO `easy_user` VALUES ('7', 'bhao', '01e53296160e1c9b7209d83110bdebd4', '1457111226', '0.0.0.0', '0', '1457110424', '1457110424');
INSERT INTO `easy_user` VALUES ('11', 'aa', '4124bc0a9335c27f086f24ba207a4912', '1454233350', '0.0.0.0', '1', '1454233948', '1454233948');

-- -----------------------------
-- Table structure for `easy_wechat`
-- -----------------------------
DROP TABLE IF EXISTS `easy_wechat`;
;

-- -----------------------------
-- Records of `easy_wechat`
-- -----------------------------
INSERT INTO `easy_wechat` VALUES ('312', 'openid', 'token', 'refreshtoken', 'nickname', 'photosrc', '1221', '12312', '321213');
